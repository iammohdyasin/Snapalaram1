package com.snapalarm.ui

import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.chip.Chip
import com.snapalarm.alarm.AlarmScheduler
import com.snapalarm.data.AlarmItem
import com.snapalarm.data.AlarmStore
import com.snapalarm.data.RandomItemProvider
import com.snapalarm.databinding.ActivityAddEditAlarmBinding
import java.util.Calendar

class AddEditAlarmActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddEditAlarmBinding
    private lateinit var store: AlarmStore
    private lateinit var scheduler: AlarmScheduler
    private var editingAlarm: AlarmItem? = null
    private var chosenTarget = RandomItemProvider.random()

    private val dayChips by lazy {
        mapOf(
            Calendar.SUNDAY to binding.chipSun,
            Calendar.MONDAY to binding.chipMon,
            Calendar.TUESDAY to binding.chipTue,
            Calendar.WEDNESDAY to binding.chipWed,
            Calendar.THURSDAY to binding.chipThu,
            Calendar.FRIDAY to binding.chipFri,
            Calendar.SATURDAY to binding.chipSat
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddEditAlarmBinding.inflate(layoutInflater)
        setContentView(binding.root)

        store = AlarmStore(this)
        scheduler = AlarmScheduler(this)

        val alarmId = intent.getIntExtra(EXTRA_ALARM_ID, -1)
        editingAlarm = if (alarmId != -1) store.get(alarmId) else null

        editingAlarm?.let { alarm ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                binding.timePicker.hour = alarm.hour
                binding.timePicker.minute = alarm.minute
            } else {
                @Suppress("DEPRECATION")
                binding.timePicker.currentHour = alarm.hour
                @Suppress("DEPRECATION")
                binding.timePicker.currentMinute = alarm.minute
            }
            binding.editLabel.setText(alarm.label)
            alarm.days.forEach { dayChips[it]?.isChecked = true }
            chosenTarget = if (alarm.targetItem.isNotBlank()) {
                RandomItemProvider.byDisplayName(alarm.targetItem)
            } else RandomItemProvider.random()
        }

        binding.textTargetPreview.text = chosenTarget.displayName
        binding.buttonShuffleTarget.setOnClickListener {
            chosenTarget = RandomItemProvider.random()
            binding.textTargetPreview.text = chosenTarget.displayName
        }

        binding.buttonCancel.setOnClickListener { finish() }
        binding.buttonSave.setOnClickListener { saveAlarm() }
    }

    private fun saveAlarm() {
        val hour: Int
        val minute: Int
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            hour = binding.timePicker.hour
            minute = binding.timePicker.minute
        } else {
            @Suppress("DEPRECATION")
            hour = binding.timePicker.currentHour
            @Suppress("DEPRECATION")
            minute = binding.timePicker.currentMinute
        }
        val label = binding.editLabel.text?.toString().orEmpty()
        val selectedDays = dayChips.filterValues { it.isChecked }.keys

        val alarm = AlarmItem(
            id = editingAlarm?.id ?: store.nextId(),
            hour = hour,
            minute = minute,
            label = label,
            enabled = true,
            days = selectedDays,
            targetItem = chosenTarget.displayName
        )
        store.save(alarm)
        scheduler.schedule(alarm)
        finish()
    }

    companion object {
        const val EXTRA_ALARM_ID = "extra_alarm_id"
    }
}
