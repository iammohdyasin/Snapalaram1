package com.snapalarm.data

import org.json.JSONArray
import org.json.JSONObject

/**
 * A single alarm configuration.
 *
 * [days] holds Calendar.DAY_OF_WEEK values (1=Sunday .. 7=Saturday) for repeating alarms.
 * An empty set means "ring once".
 */
data class AlarmItem(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String,
    val enabled: Boolean,
    val days: Set<Int> = emptySet(),
    val targetItem: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("hour", hour)
        put("minute", minute)
        put("label", label)
        put("enabled", enabled)
        put("days", JSONArray(days.toList()))
        put("targetItem", targetItem)
    }

    companion object {
        fun fromJson(json: JSONObject): AlarmItem {
            val daysArray = json.optJSONArray("days") ?: JSONArray()
            val days = mutableSetOf<Int>()
            for (i in 0 until daysArray.length()) {
                days.add(daysArray.getInt(i))
            }
            return AlarmItem(
                id = json.getInt("id"),
                hour = json.getInt("hour"),
                minute = json.getInt("minute"),
                label = json.optString("label", ""),
                enabled = json.optBoolean("enabled", true),
                days = days,
                targetItem = json.optString("targetItem", "")
            )
        }
    }
}
