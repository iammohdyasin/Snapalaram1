package com.snapalarm.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

object Notifications {
    const val ALARM_CHANNEL_ID = "snap_alarm_ringing"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)
        val channel = NotificationChannel(
            ALARM_CHANNEL_ID,
            "Alarm ringing",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Shows while a SnapAlarm alarm is ringing"
            setSound(null, null) // sound is played manually with looping, not via the channel
            enableVibration(false) // vibration handled manually so it can loop with the sound
            lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
        }
        manager.createNotificationChannel(channel)
    }
}
