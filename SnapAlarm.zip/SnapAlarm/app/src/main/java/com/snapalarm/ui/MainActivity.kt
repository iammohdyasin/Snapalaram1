package com.snapalarm.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.snapalarm.alarm.AlarmScheduler
import com.snapalarm.data.AlarmStore
import com.snapalarm.databinding.ActivityMainBinding
import com.snapalarm.util.Notifications

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var store: AlarmStore
    private lateinit var scheduler: AlarmScheduler
    private lateinit var adapter: AlarmAdapter

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* no-op: alarms still work without this, just without a heads-up look before ringing */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        store = AlarmStore(this)
        scheduler = AlarmScheduler(this)
        Notifications.ensureChannels(this)

        adapter = AlarmAdapter(
            onToggle = { alarm, enabled ->
                val updated = alarm.copy(enabled = enabled)
                store.save(updated)
                if (enabled) scheduler.schedule(updated) else scheduler.cancel(updated.id)
            },
            onDelete = { alarm ->
                store.delete(alarm.id)
                scheduler.cancel(alarm.id)
                refreshList()
            },
            onClick = { alarm ->
                startActivity(Intent(this, AddEditAlarmActivity::class.java).apply {
                    putExtra(AddEditAlarmActivity.EXTRA_ALARM_ID, alarm.id)
                })
            }
        )
        binding.recyclerAlarms.layoutManager = LinearLayoutManager(this)
        binding.recyclerAlarms.adapter = adapter

        binding.fabAdd.setOnClickListener {
            startActivity(Intent(this, AddEditAlarmActivity::class.java))
        }

        requestRuntimePermissionsIfNeeded()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun refreshList() {
        val alarms = store.getAll()
        adapter.submitList(alarms)
        binding.textEmpty.visibility = if (alarms.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        binding.recyclerAlarms.visibility = if (alarms.isEmpty()) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun requestRuntimePermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            notificationPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !scheduler.canScheduleExact()) {
            // Ask the user to grant exact-alarm scheduling so alarms fire on time.
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            } catch (_: Exception) {
                // Some OEM ROMs don't support this settings screen; alarms fall back to inexact timing.
            }
        }
    }
}
