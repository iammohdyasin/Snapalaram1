package com.snapalarm.alarm

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.snapalarm.R
import com.snapalarm.data.AlarmStore
import com.snapalarm.data.ChallengeTarget
import com.snapalarm.data.RandomItemProvider
import com.snapalarm.databinding.ActivityAlarmRingBinding
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

/**
 * Full-screen challenge shown while an alarm is ringing. The alarm cannot be dismissed from
 * here except by successfully photographing the requested item — there is deliberately no
 * "snooze"/"dismiss" shortcut, matching the app's "must snap a picture to turn it off" design.
 */
class AlarmRingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAlarmRingBinding
    private var alarmId: Int = -1
    private lateinit var target: ChallengeTarget
    private var photoUri: Uri? = null
    private var photoFile: File? = null
    private var failedAttempts = 0

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            showCapturedPhoto()
        } else {
            setStatus("")
        }
    }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) launchCamera() else setStatus("Camera permission is required to dismiss the alarm.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLockedFlags()
        binding = ActivityAlarmRingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        alarmId = intent.getIntExtra(AlarmRingService.EXTRA_ALARM_ID, -1)
        val label = intent.getStringExtra(AlarmRingService.EXTRA_ALARM_LABEL).orEmpty()
        val targetName = intent.getStringExtra(AlarmRingService.EXTRA_TARGET_ITEM).orEmpty()
        target = if (targetName.isBlank()) RandomItemProvider.random()
            else RandomItemProvider.byDisplayName(targetName)

        binding.textTime.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(System.currentTimeMillis())
        binding.textLabel.text = label
        binding.textTarget.text = target.displayName

        binding.buttonPrimary.setOnClickListener { requestCameraAndCapture() }
        binding.buttonRetake.setOnClickListener { requestCameraAndCapture() }
        binding.buttonSkip.setOnClickListener { confirmSkip() }

        // Disable back button entirely: the alarm must be resolved via the camera challenge.
        onBackPressedDispatcher.addCallback(this) {
            // no-op: consume the back press
        }
    }

    private fun setShowWhenLockedFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun requestCameraAndCapture() {
        if (checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            launchCamera()
        } else {
            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    private fun launchCamera() {
        val file = File(File(cacheDir, "snap_alarm").apply { mkdirs() }, "capture_${System.currentTimeMillis()}.jpg")
        photoFile = file
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        photoUri = uri
        setStatus("")
        binding.imagePreview.setImageDrawable(null)
        takePictureLauncher.launch(uri)
    }

    private fun showCapturedPhoto() {
        val file = photoFile ?: return
        val bitmap = decodeAndOrientBitmap(file) ?: run {
            setStatus("Couldn't read that photo, please try again.")
            return
        }
        binding.imagePreview.setImageBitmap(bitmap)
        binding.buttonRetake.visibility = android.view.View.VISIBLE
        binding.buttonPrimary.text = getString(R.string.verify_photo)
        binding.buttonPrimary.setOnClickListener { verifyPhoto(bitmap) }
        setStatus("")
    }

    private fun verifyPhoto(bitmap: Bitmap) {
        binding.progressVerifying.visibility = android.view.View.VISIBLE
        setStatus(getString(R.string.verifying))
        binding.buttonPrimary.isEnabled = false
        binding.buttonRetake.isEnabled = false

        PhotoChallengeVerifier.verify(bitmap, target) { matched, _ ->
            runOnUiThread {
                binding.progressVerifying.visibility = android.view.View.GONE
                binding.buttonPrimary.isEnabled = true
                binding.buttonRetake.isEnabled = true

                if (matched) {
                    onChallengeSolved()
                } else {
                    failedAttempts++
                    setStatus(getString(R.string.no_match, target.displayName))
                    binding.buttonPrimary.text = getString(R.string.take_photo)
                    binding.buttonPrimary.setOnClickListener { requestCameraAndCapture() }
                    if (failedAttempts >= 5) {
                        binding.buttonSkip.visibility = android.view.View.VISIBLE
                    }
                }
            }
        }
    }

    private fun onChallengeSolved() {
        Toast.makeText(this, getString(R.string.match_success, target.displayName), Toast.LENGTH_LONG).show()
        if (alarmId != -1) {
            AlarmRingService.stop(this, alarmId)
        }
        finish()
    }

    private fun confirmSkip() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Skip this challenge?")
            .setMessage("This turns the alarm off without a matching photo. Only use this if you're genuinely stuck.")
            .setPositiveButton("Skip anyway") { _, _ -> onChallengeSolved() }
            .setNegativeButton("Keep trying", null)
            .show()
    }

    private fun setStatus(text: String) {
        binding.textStatus.text = text
    }

    private fun decodeAndOrientBitmap(file: File): Bitmap? {
        val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return null
        return try {
            val exif = ExifInterface(file.absolutePath)
            val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val rotation = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (rotation == 0f) bitmap else {
                val matrix = android.graphics.Matrix().apply { postRotate(rotation) }
                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            }
        } catch (e: Exception) {
            bitmap
        }
    }

    /** Prevent finishing except through the success path above (e.g. via recents swipe-to-close
     *  is unavoidable at the OS level, but MainActivity/BootReceiver will keep the alarm state
     *  intact and the foreground notification/sound keep the alarm effectively active). */
    override fun onDestroy() {
        super.onDestroy()
    }
}
