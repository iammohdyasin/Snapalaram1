package com.snapalarm.alarm

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.snapalarm.data.AlarmStore
import com.snapalarm.util.Notifications

/**
 * Foreground service that owns the ringing alarm: looping sound, vibration and the persistent
 * notification. It keeps running until [ACTION_STOP_RINGING] is received, which only happens
 * once the photo challenge in [AlarmRingActivity] has been verified successfully.
 */
class AlarmRingService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var currentAlarmId: Int = -1

    private val stopReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val stoppedId = intent.getIntExtra(EXTRA_ALARM_ID, -1)
            if (stoppedId == currentAlarmId) {
                stopRingingAndSelf()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Notifications.ensureChannels(this)
        val filter = IntentFilter(ACTION_STOP_RINGING)
        ContextCompat.registerReceiver(this, stopReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_START_RINGING) {
            val alarmId = intent.getIntExtra(EXTRA_ALARM_ID, -1)
            val label = intent.getStringExtra(EXTRA_ALARM_LABEL).orEmpty()
            val targetItem = intent.getStringExtra(EXTRA_TARGET_ITEM).orEmpty()
            currentAlarmId = alarmId

            startForeground(NOTIFICATION_ID, buildNotification(alarmId, label))
            startSoundAndVibration()
            launchRingActivity(alarmId, label, targetItem)
        } else if (intent?.action == ACTION_STOP_RINGING) {
            stopRingingAndSelf()
        }
        return START_STICKY
    }

    private fun launchRingActivity(alarmId: Int, label: String, targetItem: String) {
        val activityIntent = Intent(this, AlarmRingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(EXTRA_ALARM_ID, alarmId)
            putExtra(EXTRA_ALARM_LABEL, label)
            putExtra(EXTRA_TARGET_ITEM, targetItem)
        }
        startActivity(activityIntent)
    }

    private fun buildNotification(alarmId: Int, label: String): Notification {
        val fullScreenIntent = Intent(this, AlarmRingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(EXTRA_ALARM_ID, alarmId)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            this, alarmId, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (label.isBlank()) "Alarm" else label
        return NotificationCompat.Builder(this, Notifications.ALARM_CHANNEL_ID)
            .setContentTitle(title)
            .setContentText("Photograph the item shown to dismiss")
            .setSmallIcon(com.snapalarm.R.drawable.ic_alarm_notification)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .setContentIntent(fullScreenPendingIntent)
            .setOngoing(true)
            .setAutoCancel(false)
            .build()
    }

    private fun startSoundAndVibration() {
        val alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getValidRingtoneUri(this)

        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            try {
                setDataSource(this@AlarmRingService, alarmUri)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                isLooping = true
                prepare()
                start()
            } catch (e: Exception) {
                release()
                mediaPlayer = null
            }
        }

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        // Nudge the alarm stream to an audible level in case it's turned all the way down.
        val maxAlarmVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
        val currentAlarmVolume = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)
        if (currentAlarmVolume < maxAlarmVolume / 2) {
            audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxAlarmVolume * 3 / 4, 0)
        }

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        val pattern = longArrayOf(0, 800, 400)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun stopRingingAndSelf() {
        mediaPlayer?.let {
            try { it.stop() } catch (_: Exception) {}
            it.release()
        }
        mediaPlayer = null
        vibrator?.cancel()
        vibrator = null

        // The one-shot state was already persisted by AlarmReceiver; nothing else to update here.
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        try { unregisterReceiver(stopReceiver) } catch (_: Exception) {}
        mediaPlayer?.release()
        mediaPlayer = null
        vibrator?.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START_RINGING = "com.snapalarm.ACTION_START_RINGING"
        const val ACTION_STOP_RINGING = "com.snapalarm.ACTION_STOP_RINGING"
        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_ALARM_LABEL = "extra_alarm_label"
        const val EXTRA_TARGET_ITEM = "extra_target_item"
        private const val NOTIFICATION_ID = 42

        fun stop(context: Context, alarmId: Int) {
            val intent = Intent(ACTION_STOP_RINGING).apply {
                setPackage(context.packageName)
                putExtra(EXTRA_ALARM_ID, alarmId)
            }
            context.sendBroadcast(intent)
        }
    }
}
