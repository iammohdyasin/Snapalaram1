package com.snapalarm.data

import android.content.Context
import org.json.JSONArray

/**
 * Simple SharedPreferences-backed persistence for alarms. No external DB dependency needed
 * for a small local list of alarms.
 */
class AlarmStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getAll(): List<AlarmItem> {
        val raw = prefs.getString(KEY_ALARMS, null) ?: return emptyList()
        val array = JSONArray(raw)
        val result = mutableListOf<AlarmItem>()
        for (i in 0 until array.length()) {
            result.add(AlarmItem.fromJson(array.getJSONObject(i)))
        }
        return result.sortedWith(compareBy({ it.hour }, { it.minute }))
    }

    fun get(id: Int): AlarmItem? = getAll().firstOrNull { it.id == id }

    fun save(alarm: AlarmItem) {
        val all = getAll().toMutableList()
        val index = all.indexOfFirst { it.id == alarm.id }
        if (index >= 0) {
            all[index] = alarm
        } else {
            all.add(alarm)
        }
        persist(all)
    }

    fun delete(id: Int) {
        val all = getAll().filterNot { it.id == id }
        persist(all)
    }

    fun nextId(): Int {
        val used = getAll().map { it.id }
        var candidate = prefs.getInt(KEY_NEXT_ID, 1)
        while (used.contains(candidate)) candidate++
        prefs.edit().putInt(KEY_NEXT_ID, candidate + 1).apply()
        return candidate
    }

    private fun persist(alarms: List<AlarmItem>) {
        val array = JSONArray()
        alarms.forEach { array.put(it.toJson()) }
        prefs.edit().putString(KEY_ALARMS, array.toString()).apply()
    }

    companion object {
        private const val PREFS_NAME = "snap_alarm_prefs"
        private const val KEY_ALARMS = "alarms_json"
        private const val KEY_NEXT_ID = "next_id"
    }
}
