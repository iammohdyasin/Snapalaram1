package com.snapalarm.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.snapalarm.data.AlarmItem
import java.util.Calendar

/**
 * Wraps AlarmManager scheduling for AlarmItems, including exact-alarm scheduling and
 * next-occurrence calculation for repeating alarms.
 */
class AlarmScheduler(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun canScheduleExact(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager.canScheduleExactAlarms()
        } else {
            true
        }
    }

    fun schedule(alarm: AlarmItem) {
        if (!alarm.enabled) {
            cancel(alarm.id)
            return
        }
        val triggerAt = nextTriggerTimeMillis(alarm)
        val pendingIntent = buildPendingIntent(alarm.id)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            } else {
                // No exact-alarm permission granted; fall back to inexact scheduling.
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
            }
        } catch (e: SecurityException) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }
    }

    fun cancel(alarmId: Int) {
        alarmManager.cancel(buildPendingIntent(alarmId))
    }

    /** Reschedules the alarm for its *next* occurrence; used after it has fired or repeats. */
    fun rescheduleNext(alarm: AlarmItem) {
        if (alarm.days.isNotEmpty() && alarm.enabled) {
            schedule(alarm)
        }
    }

    private fun buildPendingIntent(alarmId: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = ACTION_ALARM_TRIGGER
            putExtra(EXTRA_ALARM_ID, alarmId)
        }
        return PendingIntent.getBroadcast(
            context,
            alarmId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun nextTriggerTimeMillis(alarm: AlarmItem): Long {
        val now = Calendar.getInstance()
        val candidate = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, alarm.hour)
            set(Calendar.MINUTE, alarm.minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (alarm.days.isEmpty()) {
            if (candidate.before(now)) {
                candidate.add(Calendar.DAY_OF_YEAR, 1)
            }
            return candidate.timeInMillis
        }

        // Repeating alarm: find the next matching day-of-week at/after now.
        for (offset in 0..7) {
            val attempt = candidate.clone() as Calendar
            attempt.add(Calendar.DAY_OF_YEAR, offset)
            val dow = attempt.get(Calendar.DAY_OF_WEEK)
            if (alarm.days.contains(dow) && attempt.after(now)) {
                return attempt.timeInMillis
            }
        }
        // Fallback: one week from the first matching day.
        candidate.add(Calendar.DAY_OF_YEAR, 7)
        return candidate.timeInMillis
    }

    companion object {
        const val ACTION_ALARM_TRIGGER = "com.snapalarm.ACTION_ALARM_TRIGGER"
        const val EXTRA_ALARM_ID = "extra_alarm_id"
    }
}
