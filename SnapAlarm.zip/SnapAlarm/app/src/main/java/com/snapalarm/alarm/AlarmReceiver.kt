package com.snapalarm.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import com.snapalarm.data.AlarmStore

/** Fired by AlarmManager at the scheduled time; starts the ringing foreground service. */
class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val alarmId = intent.getIntExtra(AlarmScheduler.EXTRA_ALARM_ID, -1)
        if (alarmId == -1) return

        val store = AlarmStore(context)
        val alarm = store.get(alarmId) ?: return
        if (!alarm.enabled) return

        val serviceIntent = Intent(context, AlarmRingService::class.java).apply {
            action = AlarmRingService.ACTION_START_RINGING
            putExtra(AlarmRingService.EXTRA_ALARM_ID, alarm.id)
            putExtra(AlarmRingService.EXTRA_ALARM_LABEL, alarm.label)
            putExtra(AlarmRingService.EXTRA_TARGET_ITEM, alarm.targetItem)
        }
        ContextCompat.startForegroundService(context, serviceIntent)

        // Repeating alarms need to be scheduled for their next occurrence right away since
        // this trigger has just been consumed.
        if (alarm.days.isNotEmpty()) {
            AlarmScheduler(context).rescheduleNext(alarm)
        } else if (alarm.enabled) {
            // One-shot alarm: disable it now that it has fired.
            store.save(alarm.copy(enabled = false))
        }
    }
}
