package com.snapalarm.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.snapalarm.data.AlarmStore

/** Re-registers all enabled alarms with AlarmManager after a device reboot. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val store = AlarmStore(context)
        val scheduler = AlarmScheduler(context)
        store.getAll().filter { it.enabled }.forEach { scheduler.schedule(it) }
    }
}
