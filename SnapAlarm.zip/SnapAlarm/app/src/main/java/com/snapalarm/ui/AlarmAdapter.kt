package com.snapalarm.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.snapalarm.data.AlarmItem
import com.snapalarm.databinding.ItemAlarmBinding
import java.util.Calendar

class AlarmAdapter(
    private val onToggle: (AlarmItem, Boolean) -> Unit,
    private val onDelete: (AlarmItem) -> Unit,
    private val onClick: (AlarmItem) -> Unit
) : RecyclerView.Adapter<AlarmAdapter.AlarmViewHolder>() {

    private var items: List<AlarmItem> = emptyList()

    fun submitList(newItems: List<AlarmItem>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AlarmViewHolder {
        val binding = ItemAlarmBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return AlarmViewHolder(binding)
    }

    override fun onBindViewHolder(holder: AlarmViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    inner class AlarmViewHolder(private val binding: ItemAlarmBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(alarm: AlarmItem) {
            binding.textTime.text = String.format("%02d:%02d", alarm.hour, alarm.minute)
            binding.textLabel.text = alarm.label
            binding.textLabel.visibility = if (alarm.label.isBlank()) android.view.View.GONE else android.view.View.VISIBLE
            binding.textDays.text = formatDays(alarm.days)
            binding.switchEnabled.setOnCheckedChangeListener(null)
            binding.switchEnabled.isChecked = alarm.enabled
            binding.switchEnabled.setOnCheckedChangeListener { _, isChecked ->
                onToggle(alarm, isChecked)
            }
            binding.buttonDelete.setOnClickListener { onDelete(alarm) }
            binding.root.setOnClickListener { onClick(alarm) }
        }

        private fun formatDays(days: Set<Int>): String {
            if (days.isEmpty()) return "One-time"
            val names = mapOf(
                Calendar.SUNDAY to "Sun", Calendar.MONDAY to "Mon", Calendar.TUESDAY to "Tue",
                Calendar.WEDNESDAY to "Wed", Calendar.THURSDAY to "Thu", Calendar.FRIDAY to "Fri",
                Calendar.SATURDAY to "Sat"
            )
            val ordered = listOf(
                Calendar.SUNDAY, Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY,
                Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY
            )
            return ordered.filter { days.contains(it) }.joinToString(", ") { names[it].orEmpty() }
        }
    }
}
