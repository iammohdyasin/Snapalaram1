package com.snapalarm.data

/**
 * Household items the alarm can challenge the user to find and photograph, along with the
 * ML Kit generic-image-labels that count as a match. ML Kit's bundled labeler returns
 * generic (ImageNet-style) labels, so each target lists several acceptable synonyms.
 */
data class ChallengeTarget(val displayName: String, val acceptedLabels: List<String>)

object RandomItemProvider {

    val ALL_TARGETS = listOf(
        ChallengeTarget("a book", listOf("book", "publication", "novel")),
        ChallengeTarget("a pair of shoes", listOf("shoe", "footwear", "sneakers", "sandal")),
        ChallengeTarget("a cup or mug", listOf("cup", "mug", "coffee cup", "teacup", "drinkware")),
        ChallengeTarget("a bottle", listOf("bottle", "water bottle", "drink")),
        ChallengeTarget("a chair", listOf("chair", "furniture")),
        ChallengeTarget("a clock or watch", listOf("clock", "watch", "alarm clock")),
        ChallengeTarget("a houseplant", listOf("plant", "houseplant", "flowerpot", "flower")),
        ChallengeTarget("a pillow", listOf("pillow", "cushion", "bedding")),
        ChallengeTarget("a bag", listOf("bag", "luggage and bags", "handbag", "backpack")),
        ChallengeTarget("a toothbrush", listOf("toothbrush", "personal care")),
        ChallengeTarget("a remote control", listOf("remote control", "electronics")),
        ChallengeTarget("a towel", listOf("towel", "linens")),
        ChallengeTarget("a spoon or fork", listOf("spoon", "fork", "cutlery", "tableware")),
        ChallengeTarget("a plate or bowl", listOf("plate", "bowl", "tableware", "dishware")),
        ChallengeTarget("a set of keys", listOf("key", "lock")),
        ChallengeTarget("a charger or cable", listOf("cable", "electronics", "charger")),
        ChallengeTarget("a mirror", listOf("mirror")),
        ChallengeTarget("a picture frame", listOf("picture frame", "art", "wall")),
        ChallengeTarget("a candle", listOf("candle")),
        ChallengeTarget("a houseplant pot", listOf("flowerpot", "plant", "pottery"))
    )

    fun random(): ChallengeTarget = ALL_TARGETS.random()

    fun byDisplayName(name: String): ChallengeTarget =
        ALL_TARGETS.firstOrNull { it.displayName == name } ?: random()
}
