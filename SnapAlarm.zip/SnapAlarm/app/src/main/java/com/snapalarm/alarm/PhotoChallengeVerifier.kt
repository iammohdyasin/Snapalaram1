package com.snapalarm.alarm

import android.graphics.Bitmap
import com.google.android.gms.tasks.Task
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.snapalarm.data.ChallengeTarget

/**
 * Runs the on-device (bundled model, fully offline) ML Kit image labeler over a captured photo
 * and decides whether it plausibly shows the requested household item.
 */
object PhotoChallengeVerifier {

    private const val CONFIDENCE_THRESHOLD = 0.55f
    private val labeler by lazy {
        ImageLabeling.getClient(
            ImageLabelerOptions.Builder()
                .setConfidenceThreshold(CONFIDENCE_THRESHOLD)
                .build()
        )
    }

    /** Calls [onResult] with true/false once labeling completes; never throws to the caller. */
    fun verify(bitmap: Bitmap, target: ChallengeTarget, onResult: (Boolean, List<String>) -> Unit) {
        val image = InputImage.fromBitmap(bitmap, 0)
        val task: Task<*> = labeler.process(image)
            .addOnSuccessListener { labels ->
                val foundLabels = labels.map { it.text.lowercase() }
                val matched = foundLabels.any { found ->
                    target.acceptedLabels.any { accepted ->
                        found.contains(accepted.lowercase()) || accepted.lowercase().contains(found)
                    }
                }
                onResult(matched, foundLabels)
            }
            .addOnFailureListener {
                onResult(false, emptyList())
            }
    }
}
