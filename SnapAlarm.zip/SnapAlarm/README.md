# SnapAlarm

An Android alarm clock that **won't stop ringing until you photograph a random household
item**. When the alarm fires, it shows a full-screen "go find and snap a photo of ___" prompt.
The alarm keeps ringing and vibrating — no snooze, no swipe-to-dismiss — until you take a photo
that an on-device AI model recognizes as the requested item.

## How it works

1. **Add an alarm** — pick a time, an optional label, and which days to repeat on. Each alarm
   is assigned a random target item (tap "Shuffle item" to reroll) from a list of ~20 common
   household things (a book, a shoe, a mug, a chair, a plant, keys, a towel, etc).
2. **When it fires**, a foreground service starts the alarm tone (your device's default alarm
   sound, looped) and continuous vibration, and launches a full-screen activity over the lock
   screen showing the target item.
3. **You tap "Take Photo"**, which opens your camera app. After capturing, the photo shows as a
   preview with a "Verify Photo" button.
4. **On-device image recognition** (Google ML Kit's bundled image-labeling model — runs fully
   offline, no network/account needed) checks whether the photo's labels match the requested
   item. If it matches, the alarm stops immediately. If not, you get a "try again" message and
   can retake the photo — the alarm keeps ringing throughout.
5. As a safety valve (not required, but avoids anyone getting truly stuck), a small "Skip this
   once" link appears after 5 failed attempts, behind a confirmation dialog.

## Project structure

```
app/src/main/java/com/snapalarm/
├── data/
│   ├── AlarmItem.kt            # alarm data model (+ JSON serialization)
│   ├── AlarmStore.kt           # SharedPreferences-backed persistence
│   └── RandomItemProvider.kt   # the list of challenge items + accepted ML Kit labels
├── alarm/
│   ├── AlarmScheduler.kt       # AlarmManager scheduling (exact alarms, repeat handling)
│   ├── AlarmReceiver.kt        # fires when AlarmManager triggers
│   ├── BootReceiver.kt         # reschedules alarms after device reboot
│   ├── AlarmRingService.kt     # foreground service: loops sound + vibration
│   ├── AlarmRingActivity.kt    # full-screen "snap a photo" challenge UI
│   └── PhotoChallengeVerifier.kt  # runs ML Kit image labeling against the target
├── ui/
│   ├── MainActivity.kt         # alarm list
│   ├── AddEditAlarmActivity.kt # create/edit an alarm
│   └── AlarmAdapter.kt         # RecyclerView adapter for the list
└── util/Notifications.kt       # notification channel setup
```

## Building

This is a standard Gradle/Android Studio project (Kotlin, AGP 8.5.2, compileSdk 34, minSdk 26).

**Easiest path — Android Studio:**
1. Open the `SnapAlarm/` folder in Android Studio (Iguana/Koala or newer).
2. Let it sync Gradle (it will auto-generate the Gradle wrapper jar).
3. Run on a device or emulator with a camera. A real device is strongly recommended since
   you'll actually need to photograph objects around you.

**Command line**, if you have the Android SDK and a JDK 17 installed:
```bash
cd SnapAlarm
gradle wrapper --gradle-version 8.7   # generates gradlew/gradlew.bat (not checked in)
./gradlew assembleDebug
# APK output: app/build/outputs/apk/debug/app-debug.apk
```
Set `ANDROID_HOME`/`local.properties` to point at your Android SDK if Gradle can't find it.

> Note: this project was authored and reviewed in a sandbox without the Android SDK installed,
> so it hasn't been compiled here — go through the sync/build step in Android Studio first to
> catch anything environment-specific (SDK/AGP/Kotlin version mismatches, etc).

## Permissions

| Permission | Why |
|---|---|
| `CAMERA` | to launch the camera and capture the verification photo |
| `SCHEDULE_EXACT_ALARM` / `USE_EXACT_ALARM` | alarms must fire at the exact minute |
| `POST_NOTIFICATIONS` | required on Android 13+ to show the ringing notification |
| `RECEIVE_BOOT_COMPLETED` | reschedules alarms after the phone restarts |
| `VIBRATE`, `WAKE_LOCK`, `FOREGROUND_SERVICE*` | keep the alarm ringing and the screen wakeable |
| `DISABLE_KEYGUARD` | show the challenge screen over the lock screen |

On Android 12+ (API 31+), the app will prompt you once to allow "exact alarms" in system
settings — without it, alarms may fire a little late.

## Design notes / limitations

- **Matching is best-effort.** ML Kit's bundled labeler is a generic ~400-class image classifier,
  not custom-trained on these exact items, so it occasionally misses an item under bad lighting
  or won't recognize an unusual angle. The accepted-label lists in `RandomItemProvider.kt`
  include several synonyms per item to make matching more forgiving; you can tune the confidence
  threshold in `PhotoChallengeVerifier.kt` (`CONFIDENCE_THRESHOLD`, default 0.55) or expand the
  synonym lists if certain items are being missed.
- **No snooze/dismiss shortcut** is provided on purpose, per the "shouldn't turn off until..."
  requirement — only a photo match (or the deliberate 5-failed-attempts skip) stops it.
- **Storage** is a lightweight local JSON file in SharedPreferences — no server, no account,
  everything (including the photo verification) happens on-device.
- To add/change the pool of challenge items, edit `RandomItemProvider.ALL_TARGETS`.
